<?php
include("header.php");
?>

<div class="row" style="background-image: url('image/homebanner2.jpg');">

</div>
<div class="container-fluid" >
    <div class="container"  >
        <div class="row">
            <div class="col-sm-8">
                <div class="row">
                    <h2 style="font-weight:600; font-size:40px; font-family:Verdana;">Introduction of Online Examination System </h2><br>
                    <p style="text-align:justify; font-size:24px; font-family:calibri;">
                        This Project is a learning management system. The analysis steps of project are given below:- <br/>
                       <b> Accessibility:-</b>

                        Online examination systems provide accessibility to students and candidates from anywhere with an internet connection. This eliminates geographical barriers and allows for participation from remote locations.
                            <br>
                        <b>Convenience:-</b>

                        Candidates can take exams at their convenience, as per their schedule, without the need to travel to a physical location. This flexibility benefits working professionals, students with busy schedules, or those with mobility issues.


                    </p>
                </div>
            </div>
            <div class="col-sm-4 text-center">
                <h2  style="font-weight:600; font-size:40px; font-family:Verdana;">
                
            Team Leader
            </h2>
            <img src="image/mypic.jpg" height="300" width="320" alt="">
            </div>
        </div>
        <div class="row" style="margin-top:15px;">
            <div class="col-sm-3 " >
                <img src="image/Himanshu.jpg" height="250" width="250" style="border-radius:16px; padding:10px;" alt="">
            </div>
            <div class="col-sm-3  ">
                <img src="image/Himanshu.jpg" height="250" width="250" style="border-radius:16px; padding:10px;" alt="">
            </div>
            <div class="col-sm-3 " >
                <img src="image/Himanshu.jpg" height="250" width="250" style="border-radius:16px; padding:10px;" alt="">
            </div>
            <div class="col-sm-3  ">
                <img src="image/Himanshu.jpg" height="250" width="250" style="border-radius:16px; padding:10px;" alt="">
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>