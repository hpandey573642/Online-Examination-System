-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2024 at 05:16 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineexam`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(2, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('558922117fcef', '5589221195248'),
('55892211e44d5', '55892211f1fa7'),
('558922894c453', '558922895ea0a'),
('558922899ccaa', '55892289aa7cf'),
('558923538f48d', '558923539a46c'),
('55892353f05c4', '55892354051be'),
('66576585b641a', '66576585b6c87'),
('66576585b8e3c', '66576585b96c7'),
('66576585bc0a5', '66576585bd1d3'),
('66576585bf800', '66576585bffd4'),
('66576585c2b50', '66576585c3371'),
('66576585c57a9', '66576585c5f2c'),
('66576585c808f', '66576585c8676'),
('66576585caec1', '66576585cb5ba'),
('66576585cdb48', '66576585ce468'),
('66576585d0d7a', '66576585d1541');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `feedback`, `date`, `time`) VALUES
('666715c79b796', 'Deepak Kashyap', 'deepak@gmail.com', 'Issues Working', 'Hello Sir, This Project is taking too much load , it is not being load properly !!', '2024-06-10', '05:03:35pm');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('deepak@gmail.com', '558922ec03021', -2, 2, 0, 2, '2024-06-10 14:57:03'),
('deepak@gmail.com', '6657620de67d7', 4, 10, 4, 6, '2024-06-10 15:00:25');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('558922117fcef', 'echo', '5589221195248'),
('558922117fcef', 'print', '558922119525a'),
('558922117fcef', 'printf', '5589221195265'),
('558922117fcef', 'cout', '5589221195270'),
('55892211e44d5', 'int a', '55892211f1f97'),
('55892211e44d5', '$a', '55892211f1fa7'),
('55892211e44d5', 'long int a', '55892211f1fb4'),
('55892211e44d5', 'int a$', '55892211f1fbd'),
('558922894c453', 'cin>>a;', '558922895ea0a'),
('558922894c453', 'cin<<a;', '558922895ea26'),
('558922894c453', 'cout>>a;', '558922895ea34'),
('558922894c453', 'cout<a;', '558922895ea41'),
('558922899ccaa', 'cout', '55892289aa7cf'),
('558922899ccaa', 'cin', '55892289aa7df'),
('558922899ccaa', 'print', '55892289aa7eb'),
('558922899ccaa', 'printf', '55892289aa7f5'),
('558923538f48d', '255.0.0.0', '558923539a46c'),
('558923538f48d', '255.255.255.0', '558923539a480'),
('558923538f48d', '255.255.0.0', '558923539a48b'),
('558923538f48d', 'none of these', '558923539a495'),
('55892353f05c4', '192.168.1.100', '5589235405192'),
('55892353f05c4', '172.168.16.2', '55892354051a3'),
('55892353f05c4', '10.0.0.0.1', '55892354051b4'),
('55892353f05c4', '11.11.11.11', '55892354051be'),
('66576585b641a', 'GreeksQuiz', '66576585b6c83'),
('66576585b641a', 'Quiz', '66576585b6c87'),
('66576585b641a', '1005', '66576585b6c88'),
('66576585b641a', 'Compile-time error', '66576585b6c89'),
('66576585b8e3c', 'Dennis Rechard', '66576585b96c5'),
('66576585b8e3c', 'Dennis M.Ritchie', '66576585b96c7'),
('66576585b8e3c', 'Bjarne Stroutstrup', '66576585b96c8'),
('66576585b8e3c', 'Anders Hejlsberg', '66576585b96c9'),
('66576585bc0a5', '1962', '66576585bd1c7'),
('66576585bc0a5', '1978', '66576585bd1d1'),
('66576585bc0a5', '1979', '66576585bd1d2'),
('66576585bc0a5', '1972', '66576585bd1d3'),
('66576585bf800', 'Basic', '66576585bffc6'),
('66576585bf800', 'Cobol', '66576585bffd2'),
('66576585bf800', 'C++', '66576585bffd3'),
('66576585bf800', 'B', '66576585bffd4'),
('66576585c2b50', '32', '66576585c3371'),
('66576585c2b50', '33', '66576585c3374'),
('66576585c2b50', '64', '66576585c3375'),
('66576585c2b50', '18', '66576585c3376'),
('66576585c57a9', 'for', '66576585c5f27'),
('66576585c57a9', 'while ', '66576585c5f2b'),
('66576585c57a9', 'do-while ', '66576585c5f2c'),
('66576585c57a9', 'switch', '66576585c5f2d'),
('66576585c808f', 'C17', '66576585c8670'),
('66576585c808f', 'C18', '66576585c8674'),
('66576585c808f', 'C89', '66576585c8675'),
('66576585c808f', 'C99', '66576585c8676'),
('66576585caec1', 'Interpreter ', '66576585cb5b8'),
('66576585caec1', 'Compiler', '66576585cb5ba'),
('66576585caec1', 'Both Interpreter and Compiler', '66576585cb5bb'),
('66576585caec1', 'Assembler', '66576585cb5bc'),
('66576585cdb48', '2', '66576585ce462'),
('66576585cdb48', '3', '66576585ce466'),
('66576585cdb48', '4', '66576585ce467'),
('66576585cdb48', '5', '66576585ce468'),
('66576585d0d7a', '29', '66576585d1541'),
('66576585d0d7a', '30', '66576585d1545'),
('66576585d0d7a', '31', '66576585d1546'),
('66576585d0d7a', '32', '66576585d154f');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('558921841f1ec', '558922117fcef', 'what is command for print in php??', 4, 1),
('558921841f1ec', '55892211e44d5', 'which is a variable of php??', 4, 2),
('5589222f16b93', '558922894c453', 'what is correct statement in c++??', 4, 1),
('5589222f16b93', '558922899ccaa', 'which command is use for print the output in c++?', 4, 2),
('558922ec03021', '558923538f48d', 'what is correct mask for A class IP???', 4, 1),
('558922ec03021', '55892353f05c4', 'which is not a private IP??', 4, 2),
('6657620de67d7', '66576585b641a', '#include <stdio.h>\r\n//Assume  base address\r\nint main()\r\n{\r\nprintf(5 +  \"GeeksQuiz\");\r\n return 0;\r\n}\r\n', 4, 1),
('6657620de67d7', '66576585b8e3c', 'C language was developed by ', 4, 2),
('6657620de67d7', '66576585bc0a5', 'In which year was C language developed', 4, 3),
('6657620de67d7', '66576585bf800', 'C language is a successor to which language ?', 4, 4),
('6657620de67d7', '66576585c2b50', 'How many keywords are there in C Language?', 4, 5),
('6657620de67d7', '66576585c57a9', 'Which is not a valid keyword in C language?', 4, 6),
('6657620de67d7', '66576585c808f', 'In which version of C language , the C++ Style comment (//) are introduced>', 4, 7),
('6657620de67d7', '66576585caec1', 'The C source file is processed by the ______.', 4, 8),
('6657620de67d7', '66576585cdb48', 'How many whitespace characters are allowed in C language?', 4, 9),
('6657620de67d7', '66576585d0d7a', 'How many punctuation characters are allowed in C language?', 4, 10);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('558921841f1ec', 'Php Coding', 2, 1, 2, 5, '', 'PHP', '2015-06-23 09:06:12'),
('5589222f16b93', 'C++ Coding', 2, 1, 2, 5, '', 'c++', '2015-06-23 09:09:03'),
('558922ec03021', 'Networking', 2, 1, 2, 5, '', 'networking', '2015-06-23 09:12:12'),
('6657620de67d7', 'C Language ', 1, 0, 10, 10, 'Most Important Question in C Language', '#CLanguage', '2024-05-29 17:12:45');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('mohan@gmail.com', 0, '2024-06-10 15:01:23'),
('deepak@gmail.com', 4, '2024-06-10 15:00:25');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Deepak Kashyap', 'M', 'Indraprasth Inter College', 'deepak@gmail.com', 9219130585, 'e10adc3949ba59abbe56e057f20f883e'),
('Mohan Kumar', 'M', 'CSJM GOVT. Poly. College', 'mohan@gmail.com', 9219130585, 'e10adc3949ba59abbe56e057f20f883e'),
('Rahul Kumar', 'M', 'CSJM GOVT. Poly. College', 'rahul@gmail.com', 9219130585, 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
